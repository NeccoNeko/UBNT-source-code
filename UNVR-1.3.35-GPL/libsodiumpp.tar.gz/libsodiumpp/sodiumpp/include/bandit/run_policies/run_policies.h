#ifndef BANDIT_RUN_POLICIES_H
#define BANDIT_RUN_POLICIES_H

#include "run_policy.h"
#include "always_run_policy.h"
#include "never_run_policy.h"
#include "bandit_run_policy.h"

#endif
